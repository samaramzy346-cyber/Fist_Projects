print("Python test file for calculator project.")
print("Example test: 7 + 5 =", 7 + 5)