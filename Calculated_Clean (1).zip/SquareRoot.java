public class SquareRoot {
    public static void main(String[] args) {
        double number = 36;
        double result = Math.sqrt(number);
        System.out.println("Square root of " + number + " = " + result);
    }
}